$(document).ready(function () {

    <!-- Табы на JS -->
    // $(".dws-form").on("click", ".tab", function () {
    //    Удаляем классы active
    //     $(".dws-form .tab").removeClass("active");

    //    Добавляем класс active
    //     $(this).addClass("active");
    // });
});